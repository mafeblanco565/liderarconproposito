/**
 * Estilo Materia en movimiento: el avatar es una escultura humana central,
 * iluminada sobre grafito y con respuesta sutil al cursor, sin distracciones.
 */
import { ContactShadows, Float, Html, useGLTF } from "@react-three/drei";
import { Canvas, useFrame } from "@react-three/fiber";
import { Suspense, useMemo, useRef } from "react";
import * as THREE from "three";

const AVATAR_URL = "/manus-storage/glbavatarvendea_10002858.glb";

function Model() {
  const root = useRef<THREE.Group>(null);
  const { scene } = useGLTF(AVATAR_URL);
  const model = useMemo(() => scene.clone(true), [scene]);
  const framing = useMemo(() => {
    const bounds = new THREE.Box3().setFromObject(model);
    const size = bounds.getSize(new THREE.Vector3());
    const center = bounds.getCenter(new THREE.Vector3());
    const maxDimension = Math.max(size.x, size.y, size.z) || 1;
    const scale = 3.6 / maxDimension;

    return { center, scale };
  }, [model]);

  useFrame(({ pointer }, delta) => {
    if (!root.current) return;
    root.current.rotation.y = THREE.MathUtils.damp(
      root.current.rotation.y,
      pointer.x * 0.25,
      4,
      delta,
    );
    root.current.rotation.x = THREE.MathUtils.damp(
      root.current.rotation.x,
      -pointer.y * 0.08,
      4,
      delta,
    );
  });

  return (
    <Float speed={1.05} rotationIntensity={0.08} floatIntensity={0.18}>
      <group ref={root} dispose={null}>
        <primitive
          object={model}
          scale={framing.scale}
          position={[
            -framing.center.x * framing.scale,
            -framing.center.y * framing.scale - 0.25,
            -framing.center.z * framing.scale,
          ]}
        />
      </group>
    </Float>
  );
}

function AvatarFallback() {
  return (
    <Html center>
      <span className="avatar-loading">Cargando presencia 3D</span>
    </Html>
  );
}

export default function AvatarStage() {
  return (
    <div className="avatar-stage" aria-label="Avatar tridimensional de María Fernanda Blanco">
      <Canvas
        camera={{ position: [0, 0.15, 5.8], fov: 34 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={1.25} />
        <directionalLight position={[3.8, 5, 4]} intensity={3.1} color="#dfe9ff" />
        <pointLight position={[-4, 1, 2]} intensity={9} color="#7ce0cd" distance={10} />
        <pointLight position={[0, -2, 3]} intensity={4} color="#d4a867" distance={8} />
        <Suspense fallback={<AvatarFallback />}>
          <Model />
          <ContactShadows position={[0, -2.15, 0]} opacity={0.46} scale={4.7} blur={2.8} far={4.2} />
        </Suspense>
      </Canvas>
      <div className="avatar-stage__hint" aria-hidden="true">
        <span /> mueve el cursor
      </div>
    </div>
  );
}

useGLTF.preload(AVATAR_URL);
